import React, {Component} from 'react';
import {withStyles} from '@material-ui/core/styles/index';
import classNames from 'classnames';

const styles = theme => ({
    iframe:{
        height: '1000px'
    }
});

class BillRun extends Component {

    render()
    {
        const {classes} = this.props;
        return (
            <iframe src="https://fmsplus.jkdev.com/franchisees" className={classes.iframe}></iframe>           
        );
    }
}

export default withStyles(styles, {withTheme: true})(BillRun);
