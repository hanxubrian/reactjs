import {FuseLoadable} from '@fuse';

export const BillRunConfig = {
    settings: {
        layout: {
            config: {}
        }
    },
    routes  : [
        {
            path     : '/invoice-list',
            component: FuseLoadable({
                loader: () => import('./BillRun')
            })
        }
    ]
};
