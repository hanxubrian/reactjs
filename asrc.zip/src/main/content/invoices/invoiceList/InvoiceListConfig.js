import {FuseLoadable} from '@fuse';

export const InvoiceListConfig = {
    settings: {
        layout: {
            config: {}
        }
    },
    routes  : [
        {
            path     : '/bill-run',
            component: FuseLoadable({
                loader: () => import('./InvoiceList')
            })
        }
    ]
};
