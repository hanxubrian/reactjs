import menuService from './menuService';
export default menuService;

