import * as UserActions from 'auth/store/actions';
import * as Actions from 'store/actions';

export const REGISTER_ERROR = 'REGISTER_ERROR';
export const REGISTER_SUCCESS = 'REGISTER_SUCCESS';

